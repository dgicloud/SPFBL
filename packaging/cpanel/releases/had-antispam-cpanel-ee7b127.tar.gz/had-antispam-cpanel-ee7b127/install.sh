#!/usr/bin/env bash
set -euo pipefail
HERE=$(cd -- "$(dirname -- "$0")" && pwd)
exec bash "$HERE/integrations/cpanel/install-exim-cpanel.sh" "$@"
