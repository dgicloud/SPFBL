# Coletor de conteúdo Rspamd para Postfix

Este é o cliente leve de conteúdo do SpamFox para Postfix. Ele é separado da integração de policy SPFBL: `install.sh` continua instalando apenas a policy de envelope; para conteúdo, use os scripts `*-content-scan.sh` deste diretório.

## Fluxo seguro do piloto

1. O Postfix recebe e enfileira a mensagem pelo SMTP de entrada.
2. Apenas o serviço `smtp/inet/smtpd` recebe um transporte `pipe` after-queue. O processo roda como usuário sem login `had-content-scan` e recebe uma cópia do conteúdo.
3. O cliente retransmite os mesmos bytes ao `sendmail` local para a entrega normal e envia, em paralelo, uma cópia HTTPS autenticada ao gateway Rspamd. Há no máximo duas cópias simultâneas, limitadas por duas travas locais e pelo limite do transporte Postfix; o cliente não grava outro arquivo `.eml`.
4. Falha ou timeout do gateway deixa a entrega original seguir. Se a reinjeção local falhar, o filtro retorna erro temporário para que o Postfix tente novamente.
5. A classificação fica em MONITOR: score e ação do Rspamd não rejeitam, retêm nem mudam a entrega. Se as duas vagas de cópia estiverem ocupadas, o conteúdo daquela mensagem é ignorado para análise e a entrega continua. O envelope SMTP e o ID da fila seguem para a VM; quando o cliente estiver inscrito em autotreino e os metadados forem válidos, o Rspamd aprende automaticamente apenas veredictos extremos (spam >= 15, ham <= -2). Mensagens autenticadas e classificações intermediárias não treinam. Com o feedback SPFBL habilitado separadamente, spam de alta confiança com ticket válido também pode atualizar a reputação central após a análise.

O gateway guarda mensagens aguardando análise apenas em RAM. Uma reinicialização pode perder a cópia de análise, sem cancelar a entrega original já reinjetada. O Postfix precisa estar na versão 3.0 ou superior. A integração recusa `content_filter` global e filtros já configurados no serviço SMTP porque ainda precisam ser encadeados manualmente.

O desenho segue o [guia oficial de filtros after-queue do Postfix](https://www.postfix.org/FILTER_README.html), que documenta a reinjeção via `sendmail -G -i` e o isolamento do transporte. Os parâmetros do pipe seguem [pipe(8)](https://www.postfix.org/pipe.8.html); em particular `null_sender=` vazio preserva corretamente o remetente nulo.

## Preflight e instalação

Libere primeiro o IP público de saída do Postfix no core SPFBL e na allowlist do gateway. Crie o perfil pelo IP; o nome interno é automático e o autotreino Bayes conservador fica ligado por padrão:

```bash
had-content-scan-clients add --cidr IP_PUBLICO/32
had-content-scan-sync-allowlist
nginx -t && systemctl reload nginx
```

Depois, baixe o instalador unificado no servidor Postfix. `--check` confirma a rota e a autorização por IP sem alterar o MTA; sem argumentos, instala, recarrega o Postfix e valida o monitor:

```bash
cd /root
curl -fsSLO https://raw.githubusercontent.com/dgicloud/SPFBL/hadcloud-cpanel-installer/client/spamfox-monitor.sh
bash spamfox-monitor.sh --check
bash spamfox-monitor.sh
```

Extraia o bundle mantendo `integrations/postfix` e `integrations/content_scan` lado a lado. Antes de alterar qualquer configuração, rode o preflight:

```bash
cd integrations/postfix
sudo bash ./validate-content-scan.sh
```

Instale sem recarregar Postfix; o instalador guarda snapshot, configura o transporte apenas no serviço SMTP de entrada, instala o cliente e executa `postfix check`:

```bash
sudo bash ./install-content-scan.sh
```

Revise `/etc/postfix/master.cf` e ative em etapa separada:

```bash
sudo bash ./activate-content-scan.sh
sudo bash ./healthcheck-content-scan.sh
```

O Bayes conservador fica ativo por padrão nos perfis novos. Para também enviar feedback de spam de alta confiança ao SPFBL, habilite essa opção separadamente para o perfil na VM; ela começa desligada:

```bash
# Na VM central
had-content-scan-clients spfbl-feedback PERFIL --enable
```

O Postfix que já consulta o core SPFBL nativo recebe `Received-SPFBL` com o ticket emitido pelo core. O coletor after-queue encaminha essa cópia; o gateway extrai o ticket e o remove da mensagem enviada ao Rspamd, mas preserva o cabeçalho nativo na cópia reinjetada. O gateway também exige que a inspeção independente do cliente e a inspeção do próprio gateway concordem sobre a presença do ticket. Se não houver exatamente um ticket válido e concordante, o remetente não tiver IP público, a mensagem tiver mais de um destinatário ou o score ficar abaixo do limiar de spam, não há denúncia automática. Após a análise, o gateway envia exatamente um `SPAM <ticket>` ao SPFBL local. HAM continua sendo aprendido pelo Bayes do Rspamd; não enviamos `HAM <ticket>` ao SPFBL porque, no core atual, isso remove uma denúncia anterior daquele ticket. Para desligar:

```bash
had-content-scan-clients spfbl-feedback CLIENTE --disable
```

O preflight e o healthcheck não enviam mensagens. O healthcheck confirma a configuração gerenciada e `postfix check`; para validar o caminho de ponta a ponta, aguarde uma mensagem externa legítima a um destinatário local autorizado e confira os logs do gateway e do MTA. Não envie conteúdo sintético a destinatários de clientes.

## Logs e remoção

Os eventos locais incluem `upload_queued`, `upload_skipped` e `reinject_deferred`; o conteúdo, assunto, remetente e destinatário não são registrados. Consulte o journal/syslog do Postfix segundo a distribuição e, na VM, `journalctl -u had-content-scan-gateway.service`.

A remoção recompõe os arquivos originais e exige re-enfileirar toda a fila para limpar referências ao transporte salvo nos queue IDs. Faça isso em uma janela operacional:

```bash
sudo bash ./uninstall-content-scan.sh --reload --requeue-all
```

Se alguém editar arquivos gerenciados após a instalação, o removedor para e preserva o snapshot em `/var/lib/had-content-scan/postfix-install/current` para evitar sobrescrever alterações administrativas.

## Estado e limitações

A consulta central autenticada de 05/10/2026 confirmou um SPAM aprendido e zero HAM, abaixo do mínimo 200 por classe. O preparo do piloto de decisão nativa, testes de fila isolada e requisitos de coexistência estão no [guia supervisionado](../../docs/RSPAMD-SUPERVISED-PILOT.md); seus candidatos não estão habilitados na entrega.

- O piloto real foi validado no Enhance/Postfix `177.39.18.105`: mensagens recebidas seguiram pelo transporte after-queue, foram reinjetadas e tiveram entrega LMTP confirmada. A coleta de 24 horas identificou nove cópias ignoradas pela trava serial anterior; o coletor agora permite até duas cópias simultâneas, igual ao limite do transporte e do gateway. Isso não substitui observação de carga contínua ou avaliação estatística.
- O autotreino é automático e conservador; não depende de revisão humana por mensagem. Scores não são porcentagens de certeza; Rspamd usa seus próprios limites e balanceamento para decidir quando um exemplo pode entrar no Bayes. Os statfiles exigem pelo menos 200 HAM e 200 SPAM cada antes de o Bayes participar.
- O conteúdo segue somente ao Rspamd na VM central HAD.
- As actions Rspamd não controlam entrega. Marcação, quarentena e rejeição exigem validação posterior de falsos positivos e autorização operacional separada.
